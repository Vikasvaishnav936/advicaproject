const ZOHO_CONFIG = {
  client_id: '1000.1HBSKRX82ZELCGF9KGHXRCS240CYHA',
  client_secret: '80e4c5d6b9d01dcc9f9620531f78fdbbcf6210edfb',
  refresh_token: '1000.f7a7ddc0924cc242c1a57b102baef9c8.7e5bfbb8f05fbbdde9d515d4ff73f07a',
  api_domain: 'https://www.zohoapis.in',
  token_url: 'https://accounts.zoho.in/oauth/v2/token',
};

interface TokenData {
  access_token: string;
  expires_at: number;
}

export class ZohoClient {
  private tokenData: TokenData | null = null;
  private lastRequestTime: number = 0;
  private readonly minRequestInterval = 2000; // 2 seconds between requests

  private async wait(ms: number) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  private async throttleRequest() {
    const now = Date.now();
    const timeSinceLastRequest = now - this.lastRequestTime;
    
    if (timeSinceLastRequest < this.minRequestInterval) {
      await this.wait(this.minRequestInterval - timeSinceLastRequest);
    }
    
    this.lastRequestTime = Date.now();
  }

  async getAccessToken() {
    try {
      console.log('ZOHO Config:', {
        clientId: ZOHO_CONFIG.client_id,
        hasSecret: !!ZOHO_CONFIG.client_secret,
        hasRefreshToken: !!ZOHO_CONFIG.refresh_token
      });

      const response = await fetch(ZOHO_CONFIG.token_url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: new URLSearchParams({
          refresh_token: ZOHO_CONFIG.refresh_token,
          client_id: ZOHO_CONFIG.client_id,
          client_secret: ZOHO_CONFIG.client_secret,
          grant_type: 'refresh_token',
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Token refresh failed: ${JSON.stringify(errorData)}`);
      }

      const data = await response.json();
      console.log('Token Response:', data);
      
      if (!data.access_token) {
        throw new Error('No access token received');
      }

      this.tokenData = {
        access_token: data.access_token,
        expires_at: Date.now() + ((data.expires_in || 3600) * 1000) - 300000 // 5 minutes buffer
      };

      return this.tokenData.access_token;
    } catch (error) {
      console.error('Error getting access token:', error);
      throw error;
    }
  }

  async getRecords(module: string) {
    try {
      await this.throttleRequest();
      
      const accessToken = await this.getAccessToken();
      console.log('Using access token:', accessToken);
      
      // Build the URL with parameters
      const params = new URLSearchParams({
        fields: 'id,First_Name,Last_Name,Email,Company,Lead_Status,Created_Time,Deal_Name,Stage,Amount',
        per_page: '100',
      });

      const url = `${ZOHO_CONFIG.api_domain}/crm/v2/${module}?${params.toString()}`;
      console.log('Fetching from URL:', url); // Debug log

      const response = await fetch(url, {
        method: 'GET',
        headers: {
          'Authorization': `Zoho-oauthtoken ${accessToken}`,
          'Content-Type': 'application/json',
        },
      });

      console.log('Response status:', response.status); // Debug log
      const data = await response.json();
      console.log('Response data:', data); // Debug log

      if (!response.ok) {
        throw new Error(`Zoho API error: ${JSON.stringify(data)}`);
      }

      // Check if we have data and it's in the expected format
      if (!data || !data.data) {
        console.log('No records found or unexpected data format:', data);
        return { data: [] };
      }

      return data;
    } catch (error) {
      console.error(`Error fetching ${module} from Zoho:`, error);
      throw error;
    }
  }

  // Add method to get module fields
  async getModuleFields(module: string) {
    try {
      const accessToken = await this.getAccessToken();
      const response = await fetch(
        `${ZOHO_CONFIG.api_domain}/crm/v2/settings/fields?module=${module}`,
        {
          headers: {
            'Authorization': `Zoho-oauthtoken ${accessToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const data = await response.json();
      console.log(`Fields for ${module}:`, data); // Debug log
      return data;
    } catch (error) {
      console.error(`Error fetching fields for ${module}:`, error);
      throw error;
    }
  }

  // Add method to search records
  async searchRecords(module: string, criteria: string) {
    try {
      const accessToken = await this.getAccessToken();
      const response = await fetch(
        `${ZOHO_CONFIG.api_domain}/crm/v2/${module}/search?criteria=${encodeURIComponent(criteria)}`,
        {
          headers: {
            'Authorization': `Zoho-oauthtoken ${accessToken}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const data = await response.json();
      console.log('Search results:', data); // Debug log
      return data;
    } catch (error) {
      console.error(`Error searching ${module}:`, error);
      throw error;
    }
  }
}

export const zohoClient = new ZohoClient();