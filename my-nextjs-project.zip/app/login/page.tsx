'use client';
import styles from './Login.module.css';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { FaHeart, FaClock, FaLock, FaStumbleuponCircle } from 'react-icons/fa';
import { supabase } from '@/utils/supabase';

export default function Login() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      if (data.user) {
        // Store the session data
        localStorage.setItem('authUser', JSON.stringify(data.user));
        
        // Redirect to welcome page
        router.push('/welcome');
      }
    } catch (error: any) {
      setError(error.message || 'Failed to sign in');
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <Image
          src="/advice_logo_nobox.png" // Path to your logo image in the public folder
          alt="Advica Logo"
          width={100} // Set the width of the image
          height={100} // Set the height of the image
          className={styles.logo}
        />
        <h1 className={styles.title}>Welcome to Advica</h1>
        <p className={styles.subtitle}>Health</p>
        <p className={styles.paragrapgh}>Your personal healthcare navigation platform </p>
        <p className={styles.subparagrapgh}> <FaHeart className={styles.icon} /> 24/7 Access to HealthCare</p>
        <p className={styles.subparagrapgh}>  <FaClock className={styles.icon} /> Dedicated Care Advocates</p>
        <p className={styles.subparagrapgh}><FaStumbleuponCircle className={styles.icon} /> Comprehensive Coverage</p>
        <form className={styles.form} onSubmit={handleLogin}>
          {error && <div className={styles.error}>{error}</div>}
          <input
            type="email"
            placeholder="Email"
            className={styles.input}
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={styles.input}
            required
          />
          <button 
            type="submit" 
            className={styles.button}
            disabled={loading}
          >
            <FaLock className={styles.icon} /> 
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
        <p className={styles.signupText}>
          <a href="/forgot-password" className={styles.link}>Forgot Password?</a>
        </p>
        <p className={styles.signupText}>
          Don't have an account? <a href="/signup" className={styles.link}>Sign Up</a>
        </p>
        <p className={styles.signupText}>
         Or continue with
        </p>
        <div className={styles.careBox}>
          <div className={styles.leftCare}>
            <p>Maple Virtual Care</p>
          </div>
          <div className={styles.RightCare}>
            Inkblot Mental Health
          </div>
        </div>
        <p className={styles.signupText2}>
Need assistance? Call us at 1-833-ADVICAT (238-4221)
        </p>
      </div>
    </div>
  );
}