'use client';
import styles from './ForgotPassword.module.css';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { FaEnvelope, FaArrowLeft } from 'react-icons/fa';

export default function ForgotPassword() {
  const router = useRouter();
  const [email, setEmail] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      // Add your password reset logic here
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      if (response.ok) {
        alert('Password reset instructions have been sent to your email');
        router.push('/login');
      } else {
        const data = await response.json();
        alert(data.message || 'Failed to send reset instructions');
      }
    } catch (error) {
      console.error('Reset password error:', error);
      alert('An error occurred while processing your request');
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <Image
          src="/advice_logo_nobox.png"
          alt="Advica Logo"
          width={100}
          height={100}
          className={styles.logo}
        />
        <h1 className={styles.title}>Reset Password</h1>
        <p className={styles.subtitle}>Health</p>
        <p className={styles.paragraph}>
          Enter your email address and we'll send you instructions to reset your password
        </p>

        <form className={styles.form} onSubmit={handleSubmit}>
          <div className={styles.inputContainer}>
            <FaEnvelope className={styles.inputIcon} />
            <input
              type="email"
              placeholder="Enter your email"
              className={styles.input}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <button type="submit" className={styles.button}>
            Send Reset Instructions
          </button>
        </form>

        <p className={styles.signupText}>
          <a href="/login" className={styles.link}>
            <FaArrowLeft className={styles.icon} /> Back to Login
          </a>
        </p>

        <div className={styles.careBox}>
          <div className={styles.leftCare}>
            <p>Maple Virtual Care</p>
          </div>
          <div className={styles.rightCare}>
            Inkblot Mental Health
          </div>
        </div>

        <p className={styles.signupText2}>
          Need assistance? Call us at 1-833-ADVICAT (238-4221)
        </p>
      </div>
    </div>
  );
}