// app/api/zoho/auth/route.ts
import { NextResponse } from 'next/server';

export async function GET() {
  const clientId = '1000.2XQY1GDGABH4AUJEFOC46E1RPMXBGZ'; // Replace with your Client ID
  const redirectUri = encodeURIComponent('https://advicahealth.com/'); // Replace with your Redirect URI
  const authUrl = `https://accounts.zoho.com/oauth/v2/auth?response_type=code&client_id=${clientId}&scope=ZohoCRM.modules.ALL&redirect_uri=${redirectUri}&access_type=offline`;

  return NextResponse.redirect(authUrl);
}

// https://accounts.zoho.com/oauth/v2/auth?scope=ZohoBooks.invoices.CREATE,ZohoBooks.invoices.READ,ZohoBooks.invoices.UPDATE,ZohoBooks.invoices.DELETE&client_id=1000.57O42C3M7DTJ09H81WT36XLRHAQ36O&state=testing&response_type=code&redirect_uri=https://advicahealth.com/&access_type=offline


// https://advicahealth.com/?state=testing&code=1000.c9562f14b9841b27476e9ace3bb5f7e8.469f0734a11994118d88f7ac4ab3c0dc&location=in&accounts-server=https%3A%2F%2Faccounts.zoho.in


// https://accounts.zoho.com/oauth/v2/auth?response_type=code&client_id=1000.158JS42KNAKV1YVEM6YNQYID7EBLPQ&scope=ZohoCRM.modules.ALL&redirect_uri=https://advicahealth.com/&access_type=offline

// https://advicahealth.com/?state=testing&code=1000.f34dec025fee77cfae7b3a831661498d.80c420df9c69635c8151e0423822947c&location=in&accounts-server=https%3A%2F%2Faccounts.zoho.in