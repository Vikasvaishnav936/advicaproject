// app/api/zoho/callback/route.ts
import { NextResponse } from 'next/server';
import axios from 'axios';

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const code = searchParams.get('code');

  if (!code) {
    return NextResponse.json({ error: 'Authorization code not found' }, { status: 400 });
  }

  const clientId = '1000.2XQY1GDGABH4AUJEFOC46E1RPMXBGZ'; // Replace with your Client ID
  const clientSecret = '760093c141b384a0c5bd9298c7a6249d16964f4e91'; // Replace with your Client Secret
  const redirectUri = 'https://advicahealth.com/'; // Replace with your Redirect URI

  const tokenUrl = `https://accounts.zoho.com/oauth/v2/token?code=${code}&client_id=${clientId}&client_secret=${clientSecret}&redirect_uri=${redirectUri}&grant_type=authorization_code`;

  try {
    const response = await axios.post(tokenUrl);
    const { access_token, refresh_token } = response.data;

    // Save the tokens securely (e.g., in a database or environment variables)
    console.log('Access Token:', access_token);
    console.log('Refresh Token:', refresh_token);

    return NextResponse.json({ access_token, refresh_token });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch access token' }, { status: 500 });
  }
}