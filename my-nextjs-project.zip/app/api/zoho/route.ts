import { NextResponse } from 'next/server';
import { zohoClient } from '@/utils/zoho';

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { action, module } = body;

    console.log('API Route - Received request:', { action, module });

    if (action === 'getRecords') {
      try {
        const data = await zohoClient.getRecords(module);
        console.log('Successfully fetched data:', data);
        return NextResponse.json(data);
      } catch (zohoError: any) {
        console.error('Detailed Zoho Error:', zohoError);
        return NextResponse.json({ 
          error: zohoError.message,
          details: zohoError
        }, { 
          status: 500 
        });
      }
    }

    return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
  } catch (error: any) {
    console.error('API Route Error:', error);
    return NextResponse.json({ 
      error: error.message || 'Internal server error',
      details: error
    }, { 
      status: 500 
    });
  }
}