// app/welcome/page.tsx
'use client';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/utils/supabase';
import Link from 'next/link';
import styles from './Welcome.module.css';
import Image from 'next/image';
import { FaUser, FaCogs, FaProjectDiagram, FaInfinity, FaComments, FaSignOutAlt, FaSpinner, FaUserPlus, FaBuilding, FaFileAlt } from 'react-icons/fa';

interface ZohoRecord {
  id: string;
  Email?: string;
  First_Name?: string;
  Last_Name?: string;
  Company?: string;
  Lead_Status?: string;
  Created_Time?: string;
  Deal_Name?: string;
  Stage?: string;
  Amount?: string;
}

export default function Welcome() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [zohoData, setZohoData] = useState<{
    Leads: ZohoRecord[];
    Contacts: ZohoRecord[];
    Deals: ZohoRecord[];
  }>({
    Leads: [],
    Contacts: [],
    Deals: [],
  });
  const [activeTab, setActiveTab] = useState('Leads');
  const [fetchError, setFetchError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const tiles = [
    {
      title: 'Phase 1: Member Portal',
      link: '/phase1',
      icon: <FaUser />,
    },
    {
      title: 'Phase 2: SSO Integration',
      link: '/phase2',
    },
    {
      title: 'Phase 3: Enhanced Features',
      link: '/phase3',
    },
    {
      title: 'Project Exceptions',
      link: '/exceptions',
    },
    {
      title: 'Infrastructure Requirements',
      link: '/infrastructure',
    },
    {
      title: 'Advica Health Member Portal',
      link: '/member-portal',
    },
    {
      title: 'Software Development',
      link: '/software-development',
    },
    {
      title: 'Feedback and Continuity',
      link: '/feedback',
    },
    {
      title: 'Opinion Notes',
      link: '/opinion-notes',
    },
    {
      title: 'Appendix',
      link: '/appendix',
    },
  ];

  useEffect(() => {
    const checkUser = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.push('/login');
      } else {
        setUser(session.user);
        fetchAllData();
      }
    };
    checkUser();
  }, []);

  const fetchAllData = async () => {
    try {
      const modules = ['Leads', 'Contacts', 'Deals'];
      const responses = await Promise.all(
        modules.map(module =>
          fetch('/api/zoho', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              action: 'getRecords',
              module: module
            })
          }).then(res => res.json())
        )
      );

      const newData = {
        Leads: responses[0].data || [],
        Contacts: responses[1].data || [],
        Deals: responses[2].data || [],
      };

      setZohoData(newData);
    } catch (error) {
      console.error('Error fetching ZOHO data:', error);
      setFetchError('Failed to fetch data');
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      router.push('/login');
    } catch (error) {
      console.error('Error logging out:', error);
    }
  };

  const renderRecords = () => {
    const records = zohoData[activeTab];
    
    if (!records || records.length === 0) {
      return <div className={styles.noRecords}>No records found</div>;
    }

    return (
      <div className={styles.recordsGrid}>
        {records.map((record: ZohoRecord) => (
          <div key={record.id} className={styles.recordCard}>
            <div className={styles.recordHeader}>
              <FaUser className={styles.recordIcon} />
              <h3>
                {activeTab === 'Deals' 
                  ? record.Deal_Name 
                  : `${record.First_Name} ${record.Last_Name}`}
              </h3>
            </div>
            <div className={styles.recordDetails}>
              {activeTab === 'Deals' ? (
                <>
                  <p><strong>Stage:</strong> {record.Stage}</p>
                  <p><strong>Amount:</strong> ${record.Amount}</p>
                </>
              ) : (
                <>
                  <p><strong>Email:</strong> {record.Email}</p>
                  <p><strong>Company:</strong> {record.Company}</p>
                  <p><strong>Status:</strong> {record.Lead_Status}</p>
                </>
              )}
              <p><strong>Created:</strong> {new Date(record.Created_Time || '').toLocaleDateString()}</p>
            </div>
          </div>
        ))}
      </div>
    );
  };

  const fetchZohoData = async () => {
    setLoading(true);
    setFetchError(null);
    
    try {
      const response = await fetch('/api/zoho', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'getRecords',
          module: activeTab.charAt(0).toUpperCase() + activeTab.slice(1)
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || `Error: ${response.status}`);
      }

      if (data.data) {
        setZohoData(prevData => ({
          ...prevData,
          [activeTab]: data.data
        }));
      } else {
        setFetchError('No data available');
      }
    } catch (error: any) {
      console.error('Error details:', error);
      setFetchError(error.message || 'Failed to fetch data');
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null;

  return (
    <div className={styles.container}>
      <nav className={styles.navbar}>
        <div className={styles.navLeft}>
          <Image
            src="/advice_logo_nobox.png"
            alt="Advica Logo"
            width={50}
            height={50}
            className={styles.navLogo}
          />
          <span className={styles.navTitle}>Advica Health</span>
        </div>
        <div className={styles.navRight}>
          <div className={styles.userInfo}>
            <FaUser className={styles.userIcon} />
            <span>{user.email}</span>
          </div>
          <button onClick={handleLogout} className={styles.logoutButton}>
            <FaSignOutAlt className={styles.logoutIcon} />
            Logout
          </button>
        </div>
      </nav>

      <main className={styles.main}>
        <h1 className={styles.welcomeTitle}>Welcome to Advica Health</h1>
        <p className={styles.welcomeText}>
          Your trusted healthcare navigation platform
        </p>
        <div className={styles.grid}>
          {tiles.map((tile, index) => (
            <Link key={index} href={tile.link} className={styles.tile}>
              <div className={styles.icon}>{tile.icon}</div>
              <div>{tile.title}</div>
            </Link>
          ))}
        </div>

        <div className={styles.tabs}>
          <button
            className={`${styles.tabButton} ${activeTab === 'Leads' ? styles.active : ''}`}
            onClick={() => setActiveTab('Leads')}
          >
            <FaUserPlus /> Leads
          </button>
          <button
            className={`${styles.tabButton} ${activeTab === 'Contacts' ? styles.active : ''}`}
            onClick={() => setActiveTab('Contacts')}
          >
            <FaUser /> Contacts
          </button>
          <button
            className={`${styles.tabButton} ${activeTab === 'Deals' ? styles.active : ''}`}
            onClick={() => setActiveTab('Deals')}
          >
            <FaFileAlt /> Deals
          </button>
        </div>

        <div className={styles.recordsContainer}>
          {fetchError ? (
            <div className={styles.errorContainer}>
              <p className={styles.errorMessage}>{fetchError}</p>
              <button onClick={fetchZohoData} className={styles.retryButton}>
                Retry
              </button>
            </div>
          ) : (
            renderRecords()
          )}
        </div>
      </main>
    </div>
  );
}