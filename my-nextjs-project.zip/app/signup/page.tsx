'use client';
import styles from './Signup.module.css';
import Image from 'next/image';
import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { FaHeart, FaClock, FaLock, FaStumbleuponCircle, FaUser, FaEnvelope } from 'react-icons/fa';
import { supabase } from '@/utils/supabase';

export default function Signup() {
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    
    if (password !== confirmPassword) {
      setError('Passwords do not match');
      setLoading(false);
      return;
    }

    try {
      // Sign up with Supabase
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email,
        password,
      });

      if (authError) throw authError;

      if (authData.user) {
        // Insert additional user details into your custom users table
        const { error: profileError } = await supabase
          .from('users')
          .insert([
            {
              id: authData.user.id,
              username,
              email,
              created_at: new Date().toISOString(),
            }
          ]);

        if (profileError) throw profileError;

        alert('Signup successful! Please check your email for verification.');
        router.push('/login');
      }
    } catch (error: any) {
      setError(error.message || 'An error occurred during signup');
      console.error('Signup error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={styles.container}>
      <div className={styles.content}>
        <Image
          src="/advice_logo_nobox.png"
          alt="Advica Logo"
          width={100}
          height={100}
          className={styles.logo}
        />
        <h1 className={styles.title}>Join Advica</h1>
        <p className={styles.subtitle}>Health</p>
        <p className={styles.paragraph}>Create your account to get started</p>
        
        <form className={styles.form} onSubmit={handleSignup}>
          {error && <div className={styles.error}>{error}</div>}
          <div className={styles.inputContainer}>
            <FaEnvelope className={styles.inputIcon} />
            <input
              type="email"
              placeholder="Email"
              className={styles.input}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
          </div>
          <div className={styles.inputContainer}>
            <FaUser className={styles.inputIcon} />
            <input
              type="text"
              placeholder="Username"
              className={styles.input}
              value={username}
              onChange={(e) => setUsername(e.target.value)}
            />
          </div>
          <div className={styles.inputContainer}>
            <FaLock className={styles.inputIcon} />
            <input
              type="password"
              placeholder="Password"
              className={styles.input}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
          </div>
          <div className={styles.inputContainer}>
            <FaLock className={styles.inputIcon} />
            <input
              type="password"
              placeholder="Confirm Password"
              className={styles.input}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
            />
          </div>
          <button 
            type="submit" 
            className={styles.button}
            disabled={loading}
          >
            {loading ? 'Creating Account...' : 'Create Account'}
          </button>
        </form>

        <p className={styles.signupText}>Already have an account?</p>
        <a href="/login" className={styles.link}>Sign In</a>

        <div className={styles.careBox}>
          <div className={styles.leftCare}>
            Maple Virtual Care
          </div>
          <div className={styles.rightCare}>
            Inkblot Mental Health
          </div>
        </div>

        <p className={styles.signupText2}>
          Need assistance? Call us at 1-833-ADVICAT (238-4221)
        </p>
      </div>
    </div>
  );
}