(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_forgot-password_page_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_forgot-password_page_tsx_04199f._.js",
  "chunks": [
    "static/chunks/node_modules_next_3b5af4._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/app_forgot-password_fd8df9._.js",
    "static/chunks/app_forgot-password_ForgotPassword_module_99cca9.css"
  ],
  "source": "dynamic"
});
