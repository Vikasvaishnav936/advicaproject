(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_login_page_tsx_04199f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_login_page_tsx_04199f._.js",
  "chunks": [
    "static/chunks/node_modules_next_c6aa63._.js",
    "static/chunks/node_modules_@supabase_auth-js_dist_module_9daae1._.js",
    "static/chunks/node_modules_react-icons_fa_index_mjs_d2e2d7._.js",
    "static/chunks/node_modules_react-icons_lib_74ccc9._.js",
    "static/chunks/node_modules_@supabase_e5e3ff._.js",
    "static/chunks/_6c8c34._.js",
    "static/chunks/app_login_Login_module_81f0ce.css",
    "static/chunks/node_modules_91a49a._.js"
  ],
  "source": "dynamic"
});
